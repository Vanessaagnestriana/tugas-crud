<?php 
include 'koneksi.php';
$Id = $_GET['Id'];
$query = mysqli_query("DELETE FROM oreo WHERE Id = '$Id'") or die(mysqli_error());
if($query) {
    echo "<script>alert('Data berhasil dihapus!'); window.location='../view/index.php';</script>";
} else {
    echo "<script>alert('Data gagal dihapus'); window.location='index.php';</script>";
}
?>